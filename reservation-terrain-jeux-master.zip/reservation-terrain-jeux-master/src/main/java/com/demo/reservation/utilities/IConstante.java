package com.demo.reservation.utilities;

/**
 * 
 * @author wahid
 *
 */
public interface IConstante {

	public static String TABLE_RESERVATION = "RESERVATION";
	public static String TABLE_JOUEUR = "JOUEUR";
	public static String TABLE_TERRAIN = "TERRAIN";
	
}
